CREATE TABLE IF NOT EXISTS `product`
(
	id int(11) primary key not null auto_increment,
	name varchar(255) not null unique,
	slug varchar(255) not null unique,
	price int(11) null default 0,
	sale_price int(11) null default 0,
	image varchar(255) null,
	description text,
	status tinyint(1) null default 1,
	cat_id int(11),
	created_date int(11),
	foreign key (cat_id) references category(id)

);

CREATE TABLE IF NOT EXISTS `color`
(
	id int(11) primary key not null auto_increment,
	name varchar(50) not null unique,
	color_code varchar(7) not null unique

);

CREATE TABLE IF NOT EXISTS `product_color`
(
	product_id int(11) not null,
	color_id int(11) not null,
	foreign key (product_id) references product(id),
	foreign key (color_id) references color(id)

);


CREATE TABLE IF NOT EXISTS `customer`
(
	id int(11) primary key not null auto_increment,
	user_id int(11) not null,
	full_name varchar(100) not null,
	email varchar(100) null,
	phone varchar(100) null,
	address varchar(100) null,
	foreign key (user_id) references `user`(id)
);

CREATE TABLE IF NOT EXISTS `order`
(
	id int(11) primary key not null auto_increment,
	customer_id int(11) not null,
	total_amount int(11) null default 0,
	status tinyint(1),
	created_date int(11),
	foreign key (customer_id) references customer(id)

);

CREATE TABLE IF NOT EXISTS `order_detail`
(
	order_id int(11) not null,
	product_id int(11) null default 0,
	quantity int(3),
	price int(11),
	return_status tinyint(1),
	foreign key (order_id) references `order`(id),
	foreign key (product_id) references product(id)

);

