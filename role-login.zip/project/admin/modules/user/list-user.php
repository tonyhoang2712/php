<?php 
$total = get_count('user');
$show = 3;
$page = ceil($total/$show);
echo $page;
$users = get_all('user',false,false,3);

if (isset($_POST['username'])) {
	$users = get_like('user','username',$_POST['username']);
}
if (isset($_GET['role'])) {
	$users = get_all('user','role',$_GET['role']);
}

$get_page = isset($_GET['page']) ? $_GET['page'] : 1;
$start = $show*($get_page - 1);
if ($page > 1) {
	$users = phan_trang('user',$start,$show);
}
?>
<div class="container">
	<p>
		<form action="index.php?module=user&action=list-user" method="POST" class="form-inline" role="form">
			
			<div class="form-group">
				<a href="index.php?module=user&action=add-user" class="btn btn-success">Them moi</a>
			</div>
			<div class="form-group">
				<label class="sr-only" for="">Username</label>
				<input type="text" class="form-control" name="username" placeholder="Input username">
			</div>
		
			
		
			<button type="submit" class="btn btn-primary">Filter</button>
			<div class="form-group">
				<a href="index.php?module=user&action=list-user" class="btn btn-success">Refresh</a>
			</div>
		</form>
	</p>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>id</th>
				<th>Username</th>
				<th>Email</th>
				<th>Role</th>
				<th>Hanh dong</th>
			</tr>
		</thead>
		<tbody>
		<?php if($users) :  
			foreach ($users as $row) :
		?>
			<tr>
				<td><?php echo $row['id']; ?></td>
				<td><?php echo $row['username']; ?></td>
				<td><?php echo $row['email']; ?></td>
				<td>
					<?php if($row['role'] == 1 ) : ?>
						<a href="index.php?module=user&action=list-user&role=1" class="label label-success">Customer</a>
					<?php elseif($row['role'] == 2): ?>
						<a href="index.php?module=user&action=list-user&role=2" class="label label-warning">Moderator</a>
					<?php else: ?>
						<a href="index.php?module=user&action=list-user&role=3" class="label label-danger">Admin</a>
					<?php endif; ?>
				</td>
				<td>
					<a href="<?php to('user','edit-user',$row['id']) ?>" class="btn btn-sm btn-success">Sua</a>
					<a href="<?php to('user','delete-user',$row['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure ? ')">Xoa</a>
					<a href="<?php to('user','view-user',$row['id']) ?>" class="btn btn-sm btn-info">Xem</a>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
<?php if($page > 1) : 

$disabled1 = ($get_page == 1) ? 'hidden' : '';
$disabled2 = ($get_page == $page) ? 'hidden' : '';
// echo $link1;
 ?>
	<ul class="pagination">
		<li class="<?php echo $disabled1; ?>">
			<a href="index.php?module=user&action=list-user&page=<?php echo ($get_page-1) ?>">&laquo;</a>
		</li>
		<?php for($i =1;$i<= $page; $i++) : 
			if($get_page == $i){
				$active = 'active';
			}else{
				$active ='';
			}
		?>
			<li class="<?php echo $active; ?>"><a href="index.php?module=user&action=list-user&page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
		<?php endfor; ?>
		<li class="<?php echo $disabled2; ?>">
			<a href="index.php?module=user&action=list-user&page=<?php echo ($get_page+1) ?>">&raquo;</a>
		</li>
	</ul>
<?php endif; ?>
</div>
