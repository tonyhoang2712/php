<?php  
include 'config.php';
include 'header.php';
$user = get_one('user','email','anh@gmail.com');
$orders = get_all('`order`','customer_id',$user['id']);
?>
<div class="container">
	<table class="table ">
		<thead>
			<tr>
				<th>ID</th>
				<th>Tong tien</th>
				<th>Trang thai</th>
				<th>Ngay dat</th>
				<th>Hanh dong</th>
			</tr>
		</thead>
		<tbody>
		<?php  if($orders) : foreach($orders as $or) : ?>
			<tr>
				<th><?php  echo $or['id']; ?></th>
				<th><?php  echo $or['total_amount']; ?></th>
				<th><?php  echo $or['status']; ?></th>
				<th><?php  echo date('d/m/Y',$or['created_date']) ?></th>
				<th>Hanh dong</th>
			</tr>
		<?php  endforeach; endif; ?>
		</tbody>
	</table>
</div>
<?php 
include 'footer.php';

?>