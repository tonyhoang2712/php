<?php require '../config.php'; ?>
<?php require 'header.php'; ?>
<?php 

if (isset($_GET['module'])) {
	$m = $_GET['module']; // user
}else{
	$m = 'main';
}

if (isset($_GET['action'])) {
	$a = $_GET['action']; //list-user
	include 'modules/'.$m.'/'.$a.'.php';
	//modules/user/list-user.php
}else{
	include $m.'.php';
}

?>


<?php require 'footer.php'; ?>