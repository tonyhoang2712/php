-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2017 at 04:37 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT '1',
  `created_date` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `parent`, `status`, `created_date`) VALUES
(1, 'cat 1', 0, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `color`
--

CREATE TABLE `color` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `color_code` varchar(7) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `user_id`, `full_name`, `email`, `phone`, `address`) VALUES
(3, 59, '', 'admin@gmail.com', '1212121', '232323'),
(4, 60, '', 'xcxcx', 'cxcxc', 'xcxc'),
(5, 61, '', 'xcxc', 'xcxcx', 'xcxc'),
(6, 62, '', '', 'fdfd', 'dfdfd');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `total_amount` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_date` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `customer_id`, `total_amount`, `status`, `note`, `created_date`) VALUES
(2, 3, 246912, 0, 'Khongngngngngn', 1493388571),
(3, 4, 246912, 0, 'xcxcx', 1493388652),
(4, 5, 246912, 0, 'xcx', 1493388685),
(5, 6, 246912, 0, 'dfdfd', 1493389470),
(6, 3, 246912, 0, 'admin@gmail.com', 1493389630),
(11, 63, 493824, 0, 'sdsdsds', 1493816431),
(12, 63, 493824, 0, 'KKhong co gi', 1493816676),
(13, 63, 493824, 0, 'KKhong co gi', 1493816691),
(14, 63, 493824, 0, 'KKhong co gi', 1493816941),
(15, 63, 493824, 0, '2323232', 1493816950),
(16, 63, 493824, 0, '2323232', 1493816964),
(17, 63, 493824, 0, 'rttrt', 1493816979),
(18, 63, 493824, 0, 'ytyty', 1493817742),
(19, 63, 493824, 0, 'wewewe', 1493817932),
(20, 63, 493824, 0, 'sdsdsd', 1493818131),
(21, 63, 493824, 0, 'SDsdsdsdsdsds', 1493818173),
(22, 63, 493824, 0, 'ssdsdsdsdsd', 1493818233),
(23, 63, 493824, 0, 'asasasas', 1493818257),
(24, 63, 493824, 0, 'asasas', 1493818697),
(25, 63, 493824, 0, 'dsdsd', 1493818842),
(26, 63, 493824, 0, 'asasa', 1493818865),
(27, 63, 493824, 0, 'dfdfdfd', 1493818914),
(28, 63, 493824, 0, 'sddsds', 1493818959),
(29, 63, 493824, 0, 'dfdfdfdfd', 1493818995),
(30, 63, 493824, 0, 'dsdsdsdsds', 1493819242),
(31, 63, 246912, 0, 'fgggggggggggggggggggggggggggg', 1493819565),
(32, 62, 370368, 0, '', 1493819657),
(33, 62, 246912, 0, '', 1493819718),
(34, 62, 246912, 0, '', 1493819900),
(35, 62, 246912, 0, '', 1493819949),
(36, 62, 246912, 0, '', 1493820032),
(37, 62, 246912, 0, '', 1493820112),
(38, 62, 123456, 0, '', 1493820140),
(39, 62, 123456, 0, '', 1493820200),
(40, 64, 123456, 0, '', 1493820251),
(41, 65, 123456, 0, 'sds', 1493820556);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT '0',
  `quantity` int(3) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `return_status` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`order_id`, `product_id`, `quantity`, `price`, `return_status`) VALUES
(5, 1, 3, 0, 0),
(5, 2, 1, 123456, 0),
(5, 3, 1, 123456, 0),
(6, 1, 3, 0, 0),
(6, 2, 1, 123456, 0),
(6, 3, 1, 123456, 0),
(13, 3, 2, 123456, 0),
(13, 2, 2, 123456, 0),
(13, 1, 1, 0, 0),
(14, 3, 2, 123456, 0),
(14, 2, 2, 123456, 0),
(14, 1, 1, 0, 0),
(15, 3, 2, 123456, 0),
(15, 2, 2, 123456, 0),
(15, 1, 1, 0, 0),
(16, 3, 2, 123456, 0),
(16, 2, 2, 123456, 0),
(16, 1, 1, 0, 0),
(17, 3, 2, 123456, 0),
(17, 2, 2, 123456, 0),
(17, 1, 1, 0, 0),
(18, 3, 2, 123456, 0),
(18, 2, 2, 123456, 0),
(18, 1, 1, 0, 0),
(19, 3, 2, 123456, 0),
(19, 2, 2, 123456, 0),
(19, 1, 1, 0, 0),
(20, 3, 2, 123456, 0),
(20, 2, 2, 123456, 0),
(20, 1, 1, 0, 0),
(21, 3, 2, 123456, 0),
(21, 2, 2, 123456, 0),
(21, 1, 1, 0, 0),
(22, 3, 2, 123456, 0),
(22, 2, 2, 123456, 0),
(22, 1, 1, 0, 0),
(23, 3, 2, 123456, 0),
(23, 2, 2, 123456, 0),
(23, 1, 1, 0, 0),
(24, 3, 2, 123456, 0),
(24, 2, 2, 123456, 0),
(24, 1, 1, 0, 0),
(25, 3, 2, 123456, 0),
(25, 2, 2, 123456, 0),
(25, 1, 1, 0, 0),
(26, 3, 2, 123456, 0),
(26, 2, 2, 123456, 0),
(26, 1, 1, 0, 0),
(27, 3, 2, 123456, 0),
(27, 2, 2, 123456, 0),
(27, 1, 1, 0, 0),
(28, 3, 2, 123456, 0),
(28, 2, 2, 123456, 0),
(28, 1, 1, 0, 0),
(29, 3, 2, 123456, 0),
(29, 2, 2, 123456, 0),
(29, 1, 1, 0, 0),
(30, 3, 2, 123456, 0),
(30, 2, 2, 123456, 0),
(30, 1, 1, 0, 0),
(31, 1, 1, 0, 0),
(31, 2, 1, 123456, 0),
(31, 3, 1, 123456, 0),
(32, 3, 2, 123456, 0),
(32, 2, 1, 123456, 0),
(32, 1, 1, 0, 0),
(33, 1, 1, 0, 0),
(33, 2, 1, 123456, 0),
(33, 3, 1, 123456, 0),
(34, 1, 1, 0, 0),
(34, 2, 1, 123456, 0),
(34, 3, 1, 123456, 0),
(35, 1, 2, 0, 0),
(35, 2, 1, 123456, 0),
(35, 3, 1, 123456, 0),
(36, 1, 2, 0, 0),
(36, 2, 1, 123456, 0),
(36, 3, 1, 123456, 0),
(37, 1, 2, 0, 0),
(37, 2, 1, 123456, 0),
(37, 3, 1, 123456, 0),
(38, 1, 1, 0, 0),
(38, 3, 1, 123456, 0),
(39, 1, 1, 0, 0),
(39, 3, 1, 123456, 0),
(40, 1, 1, 0, 0),
(40, 3, 1, 123456, 0),
(41, 1, 1, 0, 0),
(41, 3, 1, 123456, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) DEFAULT '0',
  `sale_price` int(11) DEFAULT '0',
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) DEFAULT '1',
  `cat_id` int(11) DEFAULT NULL,
  `created_date` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `slug`, `price`, `sale_price`, `image`, `description`, `status`, `cat_id`, `created_date`) VALUES
(1, 'fgfg', 'gfgf', 0, 0, 'bai--tap-php.PNG', 'fgfgf', 1, 1, NULL),
(2, 'San pham abc', 'san-pham-1', 123456, 12, 'anh-1.png', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero repellat impedit, magni sunt aliquid cumque, ea nemo optio consequatur cupiditate temporibus minus quasi blanditiis harum voluptatum tenetur laboriosam soluta unde.', 1, 1, NULL),
(3, 'San p[hamn121212', 'san-phan-123', 123456, 0, 'Desert.jpg', 'ewwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_color`
--

CREATE TABLE `product_color` (
  `product_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `full_name`, `phone`, `address`, `role`) VALUES
(59, 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin@gmail.com', NULL, NULL, NULL, 1),
(60, 'xcxcx', 'e10adc3949ba59abbe56e057f20f883e', 'xcxcx', NULL, NULL, NULL, 1),
(61, 'xcxc', 'e10adc3949ba59abbe56e057f20f883e', 'xcxc', NULL, NULL, NULL, 1),
(62, '', 'e10adc3949ba59abbe56e057f20f883e', 'abcdsedfd@gmail.cm', NULL, NULL, NULL, 1),
(63, 'anh@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'anh@gmail.com', 'Ngueyn van anh', '123456789', 'Abc DBC dsdsd', 1),
(64, '', 'e10adc3949ba59abbe56e057f20f883e', '', '', '', '', 1),
(65, 'abc@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'abc@gmail.com', 'asasa', '123456', 'sdsdsds', 1),
(66, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'admin123@gmail.com', 'Admin Manager', '123456', NULL, 3),
(67, 'abcadmin', 'e10adc3949ba59abbe56e057f20f883e', 'abcadmin@gmail.com', NULL, NULL, NULL, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `color_code` (`color_code`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `product_color`
--
ALTER TABLE `product_color`
  ADD KEY `product_id` (`product_id`),
  ADD KEY `color_id` (`color_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `color`
--
ALTER TABLE `color`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `order_detail_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`),
  ADD CONSTRAINT `order_detail_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `category` (`id`);

--
-- Constraints for table `product_color`
--
ALTER TABLE `product_color`
  ADD CONSTRAINT `product_color_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  ADD CONSTRAINT `product_color_ibfk_2` FOREIGN KEY (`color_id`) REFERENCES `color` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
