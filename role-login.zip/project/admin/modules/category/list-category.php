<?php 

$cats = get_all('category');

// echo '<pre>';
// var_dump($res);
?>
<div class="container">
	<p>
		<a href="index.php?module=user&action=add-user" class="btn btn-success">Them moi</a>
	</p>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>id</th>
				<th>Username</th>
				<th>Hanh dong</th>
			</tr>
		</thead>
		<tbody>
		<?php if($cats) :  
			foreach ($cats as $row) :
		?>
			<tr>
				<td><?php echo $row['id']; ?></td>
				<td><?php echo $row['name']; ?></td>
				<td><?php echo $row['parent']; ?></td>
				<td>
					<a href="<?php to('user','edit-user',$row['id']) ?>" class="btn btn-sm btn-success">Sua</a>
					<a href="<?php to('user','delete-user',$row['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure ? ')">Xoa</a>
					<a href="<?php to('user','view-user',$row['id']) ?>" class="btn btn-sm btn-info">Xem</a>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>