<?php 
$mysqli = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);


function get_all($table,$fiels_name = false,$field_val = false,$limit = false){
	global $mysqli;
	$data = [];
	$sql = "SELECT * FROM $table";

	if ($fiels_name && $field_val) {
		$sql .= " WHERE $fiels_name  = '$field_val'";
	}

	if ($limit) {
		$sql .= " LIMIT $limit";
	}
	
	$res = mysqli_query($mysqli,$sql);

	if ($res && mysqli_num_rows($res)) {
		while ($row = mysqli_fetch_assoc($res)) {
			$data[] = $row;
		}
	}

	return $data;
}

function phan_trang($table,$start,$limit){
	global $mysqli;
	$data = [];
	$sql = "SELECT * FROM $table LIMIT $start,$limit";

	$res = mysqli_query($mysqli,$sql);

	if ($res && mysqli_num_rows($res)) {
		while ($row = mysqli_fetch_assoc($res)) {
			$data[] = $row;
		}
	}

	return $data;
}
function get_like($table,$fiels_name = false,$field_val = false,$limit = false){
	global $mysqli;
	$data = [];
	$sql = "SELECT * FROM $table";

	if ($fiels_name && $field_val) {
		$sql .= " WHERE $fiels_name  LIKE '%$field_val%'";
	}

	if ($limit) {
		$sql .= " LIMIT $limit";
	}
	
	$res = mysqli_query($mysqli,$sql);

	if ($res && mysqli_num_rows($res)) {
		while ($row = mysqli_fetch_assoc($res)) {
			$data[] = $row;
		}
	}

	return $data;
}
function get_one($table,$field_name,$field_value){
	global $mysqli;
	$sql = "SELECT * FROM $table WHERE $field_name = '$field_value'";

	$res = mysqli_query($mysqli,$sql);

	
	return mysqli_fetch_assoc($res);
}

function get_count($table){
	global $mysqli;
	$sql = "SELECT * FROM $table";

	$res = mysqli_query($mysqli,$sql);
	
	return $res ? mysqli_num_rows($res) : 0;
}

function delete($table,$field_name,$field_value){
	global $mysqli;
	$sql = "DELETE FROM $table WHERE $field_name = '$field_value'";

	$res = mysqli_query($mysqli,$sql);

	return $res ? true : false;
}


function insert($table,$data = []){
	global $mysqli;
	$fields = array_keys($data);
	$values = array_values($data);
	$fields = implode('`,`', $fields);
	$values = implode("','", $values);

	$sql = "INSERT INTO $table (`$fields`) VALUES ('$values')";
	// echo $sql;die;
	if (mysqli_query($mysqli,$sql)) {
		// echo mysqli_insert_id($mysqli);die;
		return mysqli_insert_id($mysqli);
	}else{
		return false;
	}

	// echo '<pre>';
	// print_r($values);
	// echo '<br />';
	// echo $sql;
	
}

function update($table,$data = [],$where = []){
	global $mysqli;
	$sql = "UPDATE $table set ";

	foreach ($data as $key => $value) {
		$sql .= "$key = '$value' , ";
	}
	$sql = rtrim($sql,' ,')." WHERE ";
	foreach ($where as $key => $value) {
		$sql .= "$key = '$value' AND ";
	}

	$sql = rtrim($sql,' AND ');

	return mysqli_query($mysqli,$sql);

	// print_r($where);

	// echo $sql;
	// echo '<br/>';
	// echo $sql1;
	// echo '</pre>';
}
?>

