
<?php 

include 'config.php';
	$products = get_cart();
?>

<?php require 'header.php'; ?>

<div class="container">
	
	<div class="row">
		<div class="col-md-12" >
			<table class="table table-bordered table-hover" >
				<thead>
					<tr>
						<th>Image</th>
						<th width="20%">Name</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>TT</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="tbody-list-cart">
				<?php if(count($products)) : foreach($products as $p) : ?>
					<tr>
						<td>
							<img src="uploads/<?php echo $p['image'] ?>" width="50"/>
						</td>
						<td><?php echo $p['name'] ;?></td>
						<td><?php echo number_format($p['price'],0,' ',',') ;?> d</td>
						<td>
							<input type="number" value="<?php echo $p['quantity'] ;?>" style="width:60px" pattern="[0-9]{2,2}" id="qtt-<?php echo $p['id'] ?>">
						</td>
						<td>
							<?php echo thanh_tien($p['id']) ;?>
						</td>
						<td>
							<a href="update-cart.php?id=<?php echo $p['id'] ;?>" class="btn btn-xs btn-success btn-update-cart" data-id="qtt-<?php echo $p['id'] ?>">Update</a>
							<a href="view-cart.php?id=<?php echo $p['id'] ;?>" class="btn btn-xs btn-danger btn-delete-item">Delete</a>
						</td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>

			<div class="row">
				<div class="col-md-4">
					<form action="" method="POST" class="form-inline">
						<div class="form-group">
							<input type="text" class="form-control" id="" placeholder="Coupon code...">
						</div>
						<button type="submit" class="btn btn-primary">Check</button>
					</form>
				</div>
				<div class="col-md-4">
					<a href="#" class="btn btn-success">Continue shopping</a>
					<a href="#" class="btn btn-danger">Clear cart</a>
					<a href="checkout.php" class="btn btn-warning">Checkout now</a>
				</div>
				<div class="col-md-4">
					<div class="panel panel-primary">
						<div class="panel-heading">
							<h3 class="panel-title">Cost info</h3>
						</div>
						<div class="panel-body">
							<h4>Total: <?php echo get_cost(); ?></h4>
							<h4>Total: <?php echo get_cost(); ?></h4>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
if (isset($_GET['id'])) {
	clear_item($_GET['id']);
}
?>
<?php require 'footer.php'; ?>