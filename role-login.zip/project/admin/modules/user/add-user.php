<div class="container">
	<p>
		<a href="<?php to('user','list-user') ?>" class="btn btn-sm btn-success">Back to list</a>
	</p>
<div class="col-md-4">
	<form action="" method="POST" role="form">
	
		<div class="form-group">
			<label for="username">Ussername</label>
			<input type="text" class="form-control" name="username" placeholder="Input username">
		</div>
	
		<div class="form-group">
			<label for="email">Email</label>
			<input type="email" class="form-control" name="email" placeholder="Input email">
		</div>
		<div class="form-group">
			<label for="password">Password</label>
			<input type="password" class="form-control" name="password" placeholder="Input password">
		</div>
		<div class="form-group">
			<select name="role" id="inputRole" class="form-control" required="required">
				<option value="1">Customer</option>
				<option value="2">Moderator</option>
				<option value="3">Admin</option>
			</select>
		</div>
		
		<button type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>
</div>
<?php 
if (isset($_POST['username'])) {
	if (!empty($_POST['password'])) {
		$_POST['password'] = MD5($_POST['password']);
	}
	insert('user',$_POST);
	header('location: index.php?module=user&action=list-user');
}
?>
