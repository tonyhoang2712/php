
<?php require 'header.php'; ?>
<?php require 'config.php'; 
$carts = get_cart();
?>


<div class="container" id="checkout-page">
<?php if($carts) : ?>
	<div class="row">
		<div class="col-md-4">
			<form action="checkout-ajax.php" method="POST" role="form" id="form-order">
				<legend>Thanh toan</legend>
			
				<div class="form-group">
					<label for="">Ho va ten</label>
					<input type="text" class="form-control" name="full_name" placeholder="Input field">
				</div>
			
				<div class="form-group">
					<label for="">Email</label>
					<input type="text" class="form-control" name="email" placeholder="Input field">
				</div>
				<div class="form-group">
					<label for="">Phone</label>
					<input type="text" class="form-control" name="phone" placeholder="Input field">
				</div>

				<div class="form-group">
					<label for="">Address</label>
					<input type="text" class="form-control" name="address" placeholder="Input field">
				</div>
			
				<div class="form-group">
					<label for="">Note </label>
					<textarea name="note" class="form-control" rows="3" ></textarea>
				</div>
			
				
				<input type="hidden" name="total_amount" value="<?php echo get_cost(); ?>" />
				<button type="submit" name="submit" class="btn btn-primary btn-order">Submit</button>
			</form>
		</div>
		<div class="col-md-8">
			<table class="table table-bordered table-hover" >
				<thead>
					<tr>
						<th>Image</th>
						<th width="20%">Name</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>TT</th>
					</tr>
				</thead>
				<tbody id="tbody-list-cart">
				<?php if(count($carts)) : foreach($carts as $p) : ?>
					<tr>
						<td>
							<img src="uploads/<?php echo $p['image'] ?>" width="50"/>
						</td>
						<td><?php echo $p['name'] ;?></td>
						<td><?php echo number_format($p['price'],0,' ',',') ;?> d</td>
						<td>
							<?php echo $p['quantity'] ;?>
						</td>
						<td>
							<?php echo thanh_tien($p['id']) ;?>
						</td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
			<div class="jumbotron">
				<div class="container">
					<h1>Hello, world!</h1>
					<p>Contents ...</p>
					<p>
						<a class="btn btn-primary btn-lg">Learn more</a>
					</p>
				</div>
			</div>
		</div>
	</div>
<?php  else: ?>

	<div class="alert">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<strong>Error</strong> Cart empty...
		<p>
 			<a href="index.php" class="btn btn-success">Go back to home</a>
 		</p>
	</div>
<?php  endif; ?>
</div>

<div class="modal fade" id="modal-message">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Modal title</h4>
				</div>
				<div class="modal-body">
					<strong> Dat hang thanh cong</strong>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<a href="" class="btn btn-primary">Go to home</a>
				</div>
			</div>
		</div>
	</div>
<?php require 'footer.php'; ?>

