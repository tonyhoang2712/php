<?php require 'header.php'; ?>
<?php require 'config.php'; ?>

<?php 
$products = get_all('product');

?>


<div class="container">

	<div class="row">
		<div class="col-md-9 products">
			<div class="row">
			<?php if($products) : foreach($products as $p) : ?>
				<div class="col-md-4 ">
					<div class="pro-item">
						<img src="uploads/<?php echo $p['image'] ?>" class="img-responsive" />
						<h2 class="pro_name">
							<?php echo $p['name'] ;?>
						</h2>
						<h3 class="pro_price"><?php echo number_format($p['price'],0,' ',',') ;?> d</h3>
						<p class="text-center">
							<a href="add-cart.php?id=<?php echo $p['id'] ;?>" class="btn btn-xs btn-success btn-add-cart">Add cart</a>
							<a href="product.php?id=<?php echo $p['id'] ;?>" class="btn btn-xs btn-info">View</a>
						</p>
					</div>
					<!-- pro-item -->
				</div>
				<!-- col-md-4 -->
			<?php endforeach; endif; ?>
			</div>
		</div>
		<div class="col-md-3">
			<div class="panel panel-primary" id="carts">
				<div class="panel-heading">
					<h3 class="panel-title">Cart informations</h3>
				</div>
				<div class="panel-body">
					<div class="pull-left">
						<strong>So luong:</strong>
					</div>
					<div class="pull-right">
						<strong><?php echo get_qtt(); ?> item</strong>
					</div>
				</div>
				<div class="panel-body">
					<div class="pull-left">
						<strong>Tong tien:</strong>
					</div>
					<div class="pull-right">
						<strong><?php echo number_format(get_cost(),0,' ',','); ?></strong>
					</div>
				</div>
				
				<div class="panel-body">
					<p class="text-center">
						<a href="view-cart.php" class="btn btn-xs btn-success">View cart</a>
						<a href="index.php?clear-cart=true" class="btn btn-xs btn-danger btn-clear-cart">Clear cart</a>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
if (isset($_GET['clear-cart'])) {
	clear_cart();
}
?>
<?php require 'footer.php'; ?>