<?php 

if (!empty($_GET['id'])) {
	$row = get_one('user','id',$_GET['id']);
	if (isset($_POST['username'])) {
		if (!empty($_POST['password'])) {
			$_POST['password'] = MD5($_POST['password']);
		}else{
			$_POST['password'] = $row['password'];
		}

		update('user',$_POST,['id'=>$_GET['id']]);
		header('location: index.php?module=user&action=list-user');
	}
	
}else{
	echo 'Tham so id khong hop le';
}


?>
<div class="container">
<?php if($row) : ?>
<div class="col-md-4">
	<form action="" method="POST" role="form">
	
		<div class="form-group">
			<label for="username">Ussername</label>
			<input type="text" class="form-control" name="username" value="<?php echo $row['username']; ?>">
		</div>
	
		<div class="form-group">
			<label for="email">Email</label>
			<input type="email" class="form-control" name="email" value="<?php echo $row['email']; ?>">
		</div>
		<div class="form-group">
			<label for="password">Password</label>
			<input type="password" class="form-control" name="password" >
		</div>
		
		<button type="submit" class="btn btn-primary">Update</button>
	</form>
</div>
<?php 

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	if (!empty($password)) {
		$password = MD5($password);
	}else{
		$password = $row['password'];
	}
	
	$sql = "UPDATE user SET username = '$username', email ='$email', password = '$password' WHERE id=$id";

	if(mysqli_query($conn,$sql)){
		header('location: index.php?module=user&action=list-user');
	}else{
		echo 'Khong Thanh cong';
	}

}
?>

<?php else: ?>
	<div class="alert alert-warning">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<strong>Error!</strong> user not found ...
	</div>
<?php endif; ?>
</div>

