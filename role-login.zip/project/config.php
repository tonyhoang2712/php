<?php 
session_start();
include 'common/cart.php';
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'project');

require_once 'common/database.php';
require_once 'common/functions.php';


?>