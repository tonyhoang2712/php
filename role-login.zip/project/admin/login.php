<?php require '../config.php'; ?>
<?php 
if (isset($_SESSION['logIn'])) {
	header("location:index.php");
}

?>
<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Title Page</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="container">
			<div class="col-md-4">
				<?php 
					$error = [];
					if (isset($_POST['login'])) {
						$username = $_POST['username'];
						$remember = isset($_POST['remember']) ? true : false;
						$password = MD5($_POST['password']);

						$u = get_one('user','username',$username);

						if (!$u) {
							$error['Username'] = 'Khong ton tai user nay';
						}else{
							if ($u['password'] != $password) {
								$error['Password'] = 'Password khong dung';
							}
						}

						if (empty($error)) {
							$_SESSION['logIn'] = $u;
							if ($remember) {
								setcookie('login_data', $u['username'], time() + (86400 * 30), "/");
							}
							header("location:index.php");
						}
						
					}
				?>


				<?php if (!empty($error)) :
					foreach ($error as $key => $value) :
				?>
				<div class="alert">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<strong><?php echo $key; ?></strong> <?php echo $value; ?>
				</div>
				<?php endforeach; endif;?>
				<form action="" method="POST" role="form">
					<legend>Form login</legend>
				
					<div class="form-group">
						<label for="">Username</label>
						<input type="text" class="form-control" name="username" placeholder="Input username">
					</div>
				
					<div class="form-group">
						<label for="">Password</label>
						<input type="password" class="form-control" name="password" placeholder="Input password">
					</div>
					<div class="form-group">
						<div class="checkbox">
							<label>
								<input type="checkbox" name="remember" value="1">
								Remember me
							</label>
						</div>
					</div>
					<button type="submit" class="btn btn-primary" name="login">login</button>
				</form>
			</div>
		</div>


	</body>
</html>