<?php 
include 'config.php';


if (isset($_GET['id'])) {
	$product = get_one('product','id',$_GET['id']);
	add_cart($product);
	echo 'success';
}else{
	echo 'failed';
}


// echo '<pre>';
// print_r(get_cart());
?>